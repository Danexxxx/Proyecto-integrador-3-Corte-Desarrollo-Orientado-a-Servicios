package usta.gym.infrastructure.adapter.in.web;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.Rectangle;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.EnrollmentStatus;
import usta.gym.domain.model.IncomeSummary;
import usta.gym.domain.model.PlanIncome;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.time.LocalDateTime;
import java.util.List;


public final class PdfReports {

    private static final Color BRAND = new Color(0xE8, 0x26, 0x2B);
    private static final Color GRAY = new Color(0x60, 0x60, 0x60);
    private static final Color LIGHT = new Color(0xF2, 0xF4, 0xF7);

    private static final Font TITLE = new Font(Font.HELVETICA, 22, Font.BOLD, BRAND);
    private static final Font SUBTITLE = new Font(Font.HELVETICA, 10, Font.ITALIC, GRAY);
    private static final Font SMALL = new Font(Font.HELVETICA, 8, Font.NORMAL, GRAY);
    private static final Font HEADER = new Font(Font.HELVETICA, 9, Font.BOLD, Color.WHITE);
    private static final Font TEXT = new Font(Font.HELVETICA, 9);
    private static final Font BOLD = new Font(Font.HELVETICA, 9, Font.BOLD);
    private static final Font SECTION = new Font(Font.HELVETICA, 12, Font.BOLD);

    private PdfReports() {
    }


    public static byte[] enrollmentsReport(IncomeSummary summary, List<Enrollment> enrollments) {
        Document document = new Document(PageSize.LETTER.rotate(), 36, 36, 36, 36);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try {
            PdfWriter.getInstance(document, output);
            document.open();

            document.add(centered("REPORTE DE INSCRIPCIONES", TITLE, 0));
            document.add(centered("Gimnasio PowerFit - del " + Formats.date(summary.from()) + " al "
                    + Formats.date(summary.to()), SUBTITLE, 0));
            Paragraph generated = new Paragraph("Generado el " + Formats.dateTime(LocalDateTime.now()), SMALL);
            generated.setAlignment(Element.ALIGN_RIGHT);
            generated.setSpacingAfter(8);
            document.add(generated);


            document.add(new Paragraph("Resumen de ingresos", SECTION));
            PdfPTable totals = new PdfPTable(new float[]{3, 2});
            totals.setWidthPercentage(45);
            totals.setHorizontalAlignment(Element.ALIGN_LEFT);
            totals.setSpacingBefore(4);
            totals.setSpacingAfter(8);
            totalRow(totals, "Inscripciones", String.valueOf(summary.totalEnrollments()), false);
            totalRow(totals, "Canceladas", String.valueOf(summary.cancelledEnrollments()), false);
            totalRow(totals, "Ingresos brutos", Formats.money(summary.gross()), false);
            totalRow(totals, "Reembolsos", Formats.money(summary.refunds()), false);
            totalRow(totals, "INGRESO NETO", Formats.money(summary.net()), true);
            document.add(totals);


            if (!summary.byPlan().isEmpty()) {
                document.add(new Paragraph("Ingresos por plan", SECTION));
                PdfPTable byPlan = new PdfPTable(new float[]{3, 1.5f, 2});
                byPlan.setWidthPercentage(60);
                byPlan.setHorizontalAlignment(Element.ALIGN_LEFT);
                byPlan.setSpacingBefore(4);
                byPlan.setSpacingAfter(10);
                header(byPlan, "Plan", "Inscripciones", "Ingreso neto");
                for (PlanIncome p : summary.byPlan()) {
                    cell(byPlan, p.planName(), Element.ALIGN_LEFT, false);
                    cell(byPlan, String.valueOf(p.enrollments()), Element.ALIGN_CENTER, false);
                    cell(byPlan, Formats.money(p.income()), Element.ALIGN_RIGHT, false);
                }
                document.add(byPlan);
            }


            document.add(new Paragraph("Detalle de inscripciones", SECTION));
            PdfPTable table = new PdfPTable(new float[]{0.6f, 3, 1.8f, 1.5f, 1.5f, 1.8f, 1.8f, 1.6f});
            table.setWidthPercentage(100);
            table.setSpacingBefore(4);
            table.setHeaderRows(1);
            header(table, "#", "Socio", "Plan", "Inicio", "Fin", "Pagado", "Reembolso", "Estado");
            boolean zebra = false;
            for (Enrollment e : enrollments) {
                cell(table, String.valueOf(e.getId()), Element.ALIGN_CENTER, zebra);
                cell(table, e.getMember().getFullName(), Element.ALIGN_LEFT, zebra);
                cell(table, e.getPlan().getName(), Element.ALIGN_LEFT, zebra);
                cell(table, Formats.date(e.getStartDate()), Element.ALIGN_CENTER, zebra);
                cell(table, Formats.date(e.getEndDate()), Element.ALIGN_CENTER, zebra);
                cell(table, Formats.money(e.getAmountPaid()), Element.ALIGN_RIGHT, zebra);
                cell(table, Formats.money(e.getRefund()), Element.ALIGN_RIGHT, zebra);
                cell(table, e.getStatus().getLabel(), Element.ALIGN_CENTER, zebra);
                zebra = !zebra;
            }
            if (enrollments.isEmpty()) {
                PdfPCell empty = new PdfPCell(new Phrase("No hay inscripciones en este rango de fechas.", TEXT));
                empty.setColspan(8);
                empty.setPadding(8);
                table.addCell(empty);
            }
            document.add(table);
            document.close();
        } catch (DocumentException ex) {
            throw new IllegalStateException("No se pudo generar el PDF", ex);
        }
        return output.toByteArray();
    }


    public static byte[] receipt(Enrollment e) {
        Document document = new Document(new Rectangle(260f, 440f), 18, 18, 18, 18);
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        Font big = new Font(Font.HELVETICA, 15, Font.BOLD, BRAND);
        Font small = new Font(Font.HELVETICA, 8);
        Font smallBold = new Font(Font.HELVETICA, 8, Font.BOLD);
        try {
            PdfWriter.getInstance(document, output);
            document.open();
            document.add(centered("GIMNASIO POWERFIT", big, 0));
            document.add(centered("Comprobante de inscripción #" + e.getId(), new Font(Font.HELVETICA, 9, Font.BOLD), 6));
            if (e.getStatus() == EnrollmentStatus.CANCELLED) {
                document.add(centered("*** CANCELADA ***", new Font(Font.HELVETICA, 10, Font.BOLD, Color.RED), 6));
            }
            document.add(centered("Emitido: " + Formats.dateTime(e.getCreatedAt()), new Font(Font.HELVETICA, 7, Font.ITALIC, GRAY), 8));

            PdfPTable t = new PdfPTable(new float[]{1.1f, 1.9f});
            t.setWidthPercentage(100);
            line(t, "Socio", e.getMember().getFullName(), smallBold, small);
            line(t, "Documento", e.getMember().getDocumentNumber(), smallBold, small);
            line(t, "Plan", e.getPlan().getName(), smallBold, small);
            line(t, "Vigencia", Formats.date(e.getStartDate()) + " al " + Formats.date(e.getEndDate()), smallBold, small);
            line(t, "Forma de pago", e.getPaymentMethod().getLabel(), smallBold, small);
            line(t, "Precio del plan", Formats.money(e.getListPrice()), smallBold, small);
            line(t, "Descuento", "- " + Formats.money(e.getDiscount()), smallBold, small);
            line(t, "TOTAL PAGADO", Formats.money(e.getAmountPaid()), new Font(Font.HELVETICA, 10, Font.BOLD),
                    new Font(Font.HELVETICA, 10, Font.BOLD));
            if (e.getStatus() == EnrollmentStatus.CANCELLED) {
                line(t, "Reembolso", Formats.money(e.getRefund()), smallBold, small);
            }
            document.add(t);
            document.add(centered("Gracias por entrenar con nosotros", new Font(Font.HELVETICA, 7, Font.ITALIC, GRAY), 0));
            document.close();
        } catch (DocumentException ex) {
            throw new IllegalStateException("No se pudo generar el PDF", ex);
        }
        return output.toByteArray();
    }



    private static Paragraph centered(String text, Font font, float spacingAfter) {
        Paragraph p = new Paragraph(text, font);
        p.setAlignment(Element.ALIGN_CENTER);
        p.setSpacingAfter(spacingAfter);
        return p;
    }

    private static void header(PdfPTable table, String... titles) {
        for (String title : titles) {
            PdfPCell cell = new PdfPCell(new Phrase(title, HEADER));
            cell.setBackgroundColor(BRAND);
            cell.setHorizontalAlignment(Element.ALIGN_CENTER);
            cell.setPadding(5);
            cell.setBorderColor(Color.WHITE);
            table.addCell(cell);
        }
    }

    private static void cell(PdfPTable table, String text, int align, boolean zebra) {
        PdfPCell cell = new PdfPCell(new Phrase(text, TEXT));
        cell.setHorizontalAlignment(align);
        cell.setPadding(4);
        cell.setBorderColor(new Color(0xDD, 0xDD, 0xDD));
        if (zebra) {
            cell.setBackgroundColor(LIGHT);
        }
        table.addCell(cell);
    }

    private static void totalRow(PdfPTable table, String label, String value, boolean strong) {
        Font font = strong ? BOLD : TEXT;
        PdfPCell l = new PdfPCell(new Phrase(label, font));
        PdfPCell v = new PdfPCell(new Phrase(value, font));
        v.setHorizontalAlignment(Element.ALIGN_RIGHT);
        for (PdfPCell c : new PdfPCell[]{l, v}) {
            c.setPadding(4);
            c.setBorderColor(new Color(0xDD, 0xDD, 0xDD));
            if (strong) {
                c.setBackgroundColor(LIGHT);
            }
            table.addCell(c);
        }
    }

    private static void line(PdfPTable table, String label, String value, Font labelFont, Font valueFont) {
        PdfPCell l = new PdfPCell(new Phrase(label, labelFont));
        PdfPCell v = new PdfPCell(new Phrase(value, valueFont));
        v.setHorizontalAlignment(Element.ALIGN_RIGHT);
        for (PdfPCell c : new PdfPCell[]{l, v}) {
            c.setBorder(Rectangle.BOTTOM);
            c.setBorderColor(new Color(0xDD, 0xDD, 0xDD));
            c.setPadding(4);
            table.addCell(c);
        }
    }
}