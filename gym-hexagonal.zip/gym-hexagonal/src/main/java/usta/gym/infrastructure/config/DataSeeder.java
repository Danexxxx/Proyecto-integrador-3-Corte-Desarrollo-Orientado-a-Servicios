package usta.gym.infrastructure.config;

import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import org.eclipse.microprofile.config.inject.ConfigProperty;
import org.jboss.logging.Logger;
import usta.gym.application.port.out.EnrollmentRepository;
import usta.gym.application.port.out.MemberRepository;
import usta.gym.application.port.out.PlanRepository;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.Member;
import usta.gym.domain.model.PaymentMethod;
import usta.gym.domain.model.Plan;
import usta.gym.domain.service.MembershipService;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

// Carga datos de prueba la primera vez que se arranca (si las tablas están vacías).
// Usa los puertos de salida y las reglas del dominio, por eso los valores quedan coherentes.
@ApplicationScoped
public class DataSeeder {

    private static final Logger LOG = Logger.getLogger(DataSeeder.class);

    @Inject PlanRepository plans;
    @Inject MemberRepository members;
    @Inject EnrollmentRepository enrollments;

    @ConfigProperty(name = "gym.seed.enabled", defaultValue = "true")
    boolean enabled;

    private final MembershipService membership = new MembershipService();

    void onStart(@Observes StartupEvent event) {
        if (!enabled || !plans.findAll().isEmpty() || !members.findAll().isEmpty()) {
            return;
        }
        LOG.info("Cargando datos de prueba del gimnasio...");
        LocalDate today = LocalDate.now();

        Plan monthly = plan("Mensual", "Acceso total a la sala de máquinas y clases grupales", "90000", 30);
        Plan quarterly = plan("Trimestral", "Tres meses con valoración física incluida", "240000", 90);
        Plan semester = plan("Semestral", "Seis meses con plan de entrenamiento personalizado", "420000", 180);
        Plan daypass = plan("Pase de 7 días", "Semana de prueba para nuevos visitantes", "35000", 7);
        Plan annual = plan("Anual", "Doce meses, el mejor precio por mes", "720000", 365);
        annual.setActive(false);   // plan retirado: demuestra el estado "no disponible"
        plans.save(annual);

        Member laura = member("Laura Gómez Pérez", "1052398741", "laura.gomez@correo.com", "3101234567", true);
        Member carlos = member("Carlos Rodríguez Silva", "74189234", "carlos.rodriguez@correo.com", "3157654321", false);
        Member andrea = member("Andrea Torres Mora", "1049873210", "andrea.torres@correo.com", "3209876543", true);
        Member julian = member("Julián Castro Rojas", "1052001122", "julian.castro@correo.com", "3004567890", false);
        Member diana = member("Diana Martínez León", "40123456", "diana.martinez@correo.com", "3112223344", false);
        Member sergio = member("Sergio Ramírez Díaz", "1053112233", "sergio.ramirez@correo.com", "3175556677", true);
        Member paola = member("Paola Herrera Ruiz", "46789012", "paola.herrera@correo.com", "3186668899", false);
        Member felipe = member("Felipe Vargas Soto", "1050445566", "felipe.vargas@correo.com", "3023334455", false);

        // Historial: laura (estudiante); carlos fiel (3+ inscripciones previas)
        enroll(laura, monthly, today.minusDays(150), PaymentMethod.CASH);
        enroll(laura, quarterly, today.minusDays(60), PaymentMethod.CARD);
        enroll(carlos, monthly, today.minusDays(175), PaymentMethod.CASH);
        enroll(carlos, monthly, today.minusDays(140), PaymentMethod.CASH);
        enroll(carlos, quarterly, today.minusDays(105), PaymentMethod.TRANSFER);
        enroll(carlos, monthly, today.minusDays(10), PaymentMethod.TRANSFER);      // 10% de fidelidad
        enroll(andrea, semester, today.minusDays(40), PaymentMethod.CARD);
        enroll(julian, monthly, today.minusDays(95), PaymentMethod.CASH);
        enroll(julian, daypass, today.minusDays(3), PaymentMethod.CASH);
        enroll(diana, quarterly, today.minusDays(20), PaymentMethod.TRANSFER);
        enroll(sergio, monthly, today.minusDays(5), PaymentMethod.CARD);
        enroll(paola, monthly, today.minusDays(100), PaymentMethod.CASH);
        enroll(felipe, monthly, today.minusDays(70), PaymentMethod.CASH);

        // Felipe es un socio retirado: se desactiva DESPUÉS de registrar su historial
        felipe.setActive(false);
        members.save(felipe);

        // Cancelaciones de ejemplo: una con reembolso total (día 2) y una proporcional (día 12)
        cancel(sergio, today.minusDays(5), today.minusDays(3));
        cancel(diana, today.minusDays(20), today.minusDays(8));

        LOG.info("Datos de prueba cargados.");
    }

    private Plan plan(String name, String description, String price, int days) {
        return plans.save(Plan.builder().name(name).description(description)
                .price(new BigDecimal(price)).durationDays(days).build());
    }

    private Member member(String name, String document, String email, String phone, boolean student) {
        return members.save(Member.builder().fullName(name).documentNumber(document).email(email)
                .phone(phone).student(student).registeredAt(LocalDate.now().minusDays(200)).build());
    }

    // Crea una inscripción con la regla del dominio, simulando que "hoy" fue el día de inicio
    private Enrollment enroll(Member member, Plan plan, LocalDate start, PaymentMethod method) {
        List<Enrollment> history = new ArrayList<>(enrollments.findByMemberId(member.getId()));
        Enrollment e = membership.enroll(member, plan, history, start, method, start);
        e.setCreatedAt(start.atTime(10, 30));
        return enrollments.save(e);
    }

    // Cancela la inscripción de un socio que empezó en "start", como si hoy fuera "cancelDay"
    private void cancel(Member member, LocalDate start, LocalDate cancelDay) {
        enrollments.findByMemberId(member.getId()).stream()
                .filter(e -> e.getStartDate().equals(start)).findFirst()
                .ifPresent(e -> enrollments.save(membership.cancel(e, cancelDay)));
    }
}