package usta.gym.infrastructure.adapter.in.web;

import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.EnrollmentStatus;
import usta.gym.domain.model.IncomeSummary;
import usta.gym.domain.model.Member;
import usta.gym.domain.model.PaymentMethod;
import usta.gym.domain.model.Plan;
import usta.gym.domain.model.PlanIncome;

import java.util.Arrays;
import java.util.List;


public final class WebMapper {

    private WebMapper() {
    }

    public record MemberView(Long id, String fullName, String documentNumber, String email, String phone,
                             boolean student, boolean active, String registeredAt) {
    }

    public record PlanView(Long id, String name, String description, String price, int durationDays, boolean active) {
    }

    public record PlanOption(Long id, String label) {
    }

    public record MemberOption(Long id, String label) {
    }

    public record PaymentOption(String value, String label) {
    }

    public record EnrollmentView(Long id, String member, String document, String plan, String start, String end,
                                 String listPrice, String discount, String amountPaid, String refund,
                                 String method, String status, String badge, boolean cancellable) {
    }

    public record PlanIncomeView(String plan, long enrollments, String income) {
    }

    public record SummaryView(long total, long cancelled, String gross, String refunds, String net,
                              List<PlanIncomeView> byPlan) {
    }

    public static MemberView toView(Member m) {
        return new MemberView(m.getId(), m.getFullName(), m.getDocumentNumber(), m.getEmail(), m.getPhone(),
                m.isStudent(), m.isActive(), Formats.date(m.getRegisteredAt()));
    }

    public static PlanView toView(Plan p) {
        return new PlanView(p.getId(), p.getName(), p.getDescription(), Formats.money(p.getPrice()),
                p.getDurationDays(), p.isActive());
    }

    public static EnrollmentView toView(Enrollment e) {
        String badge = switch (e.getStatus()) {
            case ACTIVE -> "success";
            case EXPIRED -> "secondary";
            case CANCELLED -> "danger";
        };
        return new EnrollmentView(e.getId(), e.getMember().getFullName(), e.getMember().getDocumentNumber(),
                e.getPlan().getName(), Formats.date(e.getStartDate()), Formats.date(e.getEndDate()),
                Formats.money(e.getListPrice()), Formats.money(e.getDiscount()), Formats.money(e.getAmountPaid()),
                Formats.money(e.getRefund()), e.getPaymentMethod().getLabel(), e.getStatus().getLabel(), badge,
                e.getStatus() == EnrollmentStatus.ACTIVE);
    }

    public static SummaryView toView(IncomeSummary s) {
        List<PlanIncomeView> plans = s.byPlan().stream().map(WebMapper::toView).toList();
        return new SummaryView(s.totalEnrollments(), s.cancelledEnrollments(), Formats.money(s.gross()),
                Formats.money(s.refunds()), Formats.money(s.net()), plans);
    }

    public static PlanIncomeView toView(PlanIncome p) {
        return new PlanIncomeView(p.planName(), p.enrollments(), Formats.money(p.income()));
    }

    public static List<PaymentOption> paymentOptions() {
        return Arrays.stream(PaymentMethod.values())
                .map(m -> new PaymentOption(m.name(), m.getLabel())).toList();
    }
}