package usta.gym.infrastructure.adapter.in.web;

import io.quarkus.qute.Location;
import io.quarkus.qute.Template;
import io.quarkus.qute.TemplateInstance;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.FormParam;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import usta.gym.application.exception.ResourceNotFoundException;
import usta.gym.application.port.in.EnrollmentUseCase;
import usta.gym.application.port.in.ManageMembersUseCase;
import usta.gym.application.port.in.ManagePlansUseCase;
import usta.gym.domain.exception.BusinessRuleException;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.EnrollmentStatus;
import usta.gym.domain.model.Member;
import usta.gym.domain.model.PaymentMethod;
import usta.gym.infrastructure.adapter.in.web.WebMapper.EnrollmentView;
import usta.gym.infrastructure.adapter.in.web.WebMapper.MemberOption;
import usta.gym.infrastructure.adapter.in.web.WebMapper.MemberView;
import usta.gym.infrastructure.adapter.in.web.WebMapper.PlanOption;

import java.math.BigDecimal;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.List;


@Path("/")
@ApplicationScoped
@Produces(MediaType.TEXT_HTML)
@Tag(name = "Vista web", description = "Páginas HTML del gimnasio: inscripciones, socios, planes e inscribir")
public class WebResource {

    @Inject @Location("index.html") Template indexTemplate;
    @Inject @Location("members.html") Template membersTemplate;
    @Inject @Location("member-form.html") Template memberFormTemplate;
    @Inject @Location("enroll.html") Template enrollTemplate;
    @Inject @Location("plans.html") Template plansTemplate;

    @Inject ManageMembersUseCase members;
    @Inject ManagePlansUseCase plans;
    @Inject EnrollmentUseCase enrollments;



    @GET
    @Operation(summary = "Página principal: listado de inscripciones con filtro por estado")
    public TemplateInstance home(@QueryParam("status") String status,
                                 @QueryParam("success") String success,
                                 @QueryParam("error") String error,
                                 @QueryParam("receipt") Long receipt) {
        List<Enrollment> all = enrollments.findAll();
        List<EnrollmentView> rows = all.stream()
                .filter(e -> status == null || status.isBlank() || e.getStatus().name().equals(status))
                .map(WebMapper::toView).toList();

        LocalDate today = LocalDate.now();
        var month = enrollments.summary(today.withDayOfMonth(1), today);

        return indexTemplate
                .data("active", "home")
                .data("rows", rows)
                .data("status", status == null ? "" : status)
                .data("statuses", EnrollmentStatus.values())
                .data("activeCount", all.stream().filter(e -> e.getStatus() == EnrollmentStatus.ACTIVE).count())
                .data("membersCount", members.findAll().stream().filter(Member::isActive).count())
                .data("monthNet", Formats.money(month.net()))
                .data("success", success)
                .data("error", error)
                .data("receipt", receipt);
    }

    @POST
    @Path("/enrollments/{id}/cancel")
    @Operation(summary = "Cancelar una inscripción (calcula el reembolso)")
    public Response cancel(@PathParam("id") Long id) {
        try {
            Enrollment e = enrollments.cancel(id);
            return redirect("/", "success", "Inscripción cancelada. Reembolso: " + Formats.money(e.getRefund()));
        } catch (BusinessRuleException | ResourceNotFoundException ex) {
            return redirect("/", "error", ex.getMessage());
        }
    }



    @GET
    @Path("/enroll")
    @Operation(summary = "Formulario para inscribir un socio a un plan")
    public TemplateInstance enrollForm(@QueryParam("memberId") Long memberId) {
        return enrollPage(memberId, null, LocalDate.now().toString(), null, null);
    }

    @POST
    @Path("/enroll")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Operation(summary = "Registrar la inscripción y el pago de un socio")
    public Response enroll(@FormParam("memberId") Long memberId,
                           @FormParam("planId") Long planId,
                           @FormParam("startDate") String startDate,
                           @FormParam("paymentMethod") String paymentMethod) {
        try {
            Enrollment e = enrollments.enroll(memberId, planId, parseDate(startDate), parseMethod(paymentMethod));
            return Response.seeOther(URI.create("/?receipt=" + e.getId() + "&success="
                    + encode("Inscripción registrada. Total pagado: " + Formats.money(e.getAmountPaid())))).build();
        } catch (BusinessRuleException | ResourceNotFoundException ex) {
            // Se vuelve a mostrar el formulario conservando lo que el usuario eligió
            return Response.ok(enrollPage(memberId, planId, startDate, paymentMethod, ex.getMessage())).build();
        }
    }

    private TemplateInstance enrollPage(Long memberId, Long planId, String startDate, String method, String error) {
        List<MemberOption> memberOptions = members.findAll().stream().filter(Member::isActive)
                .map(m -> new MemberOption(m.getId(), m.getFullName() + " - " + m.getDocumentNumber()
                        + (m.isStudent() ? " (estudiante)" : ""))).toList();
        List<PlanOption> planOptions = plans.findActive().stream()
                .map(p -> new PlanOption(p.getId(), p.getName() + " - " + Formats.money(p.getPrice())
                        + " (" + p.getDurationDays() + " días)")).toList();
        return enrollTemplate
                .data("active", "enroll")
                .data("memberOptions", memberOptions)
                .data("planOptions", planOptions)
                .data("payments", WebMapper.paymentOptions())
                .data("memberId", memberId)
                .data("planId", planId)
                .data("startDate", startDate)
                .data("method", method)
                .data("error", error);
    }



    @GET
    @Path("/members")
    @Operation(summary = "Listado de socios")
    public TemplateInstance membersList(@QueryParam("success") String success, @QueryParam("error") String error) {
        List<MemberView> rows = members.findAll().stream().map(WebMapper::toView).toList();
        return membersTemplate.data("active", "members").data("rows", rows)
                .data("success", success).data("error", error);
    }

    @GET
    @Path("/members/new")
    @Operation(summary = "Formulario para registrar un socio")
    public TemplateInstance newMemberForm() {
        return memberForm(null, new MemberView(null, "", "", "", "", false, true, ""), null);
    }

    @GET
    @Path("/members/{id}/edit")
    @Operation(summary = "Formulario para editar un socio")
    public Response editMemberForm(@PathParam("id") Long id) {
        return members.findById(id)
                .map(m -> Response.ok(memberForm(id, WebMapper.toView(m), null)).build())
                .orElseGet(() -> redirect("/members", "error", "No existe el socio con id " + id));
    }

    @POST
    @Path("/members")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Operation(summary = "Registrar un nuevo socio")
    public Response createMember(@FormParam("fullName") String fullName,
                                 @FormParam("documentNumber") String documentNumber,
                                 @FormParam("email") String email,
                                 @FormParam("phone") String phone,
                                 @FormParam("student") String student) {
        boolean isStudent = student != null;
        try {
            Member m = members.create(fullName, documentNumber, email, phone, isStudent);
            return redirect("/members", "success", "Socio registrado: " + m.getFullName());
        } catch (BusinessRuleException ex) {
            MemberView typed = new MemberView(null, nz(fullName), nz(documentNumber), nz(email), nz(phone), isStudent, true, "");
            return Response.ok(memberForm(null, typed, ex.getMessage())).build();
        }
    }

    @POST
    @Path("/members/{id}")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Operation(summary = "Actualizar los datos de un socio")
    public Response updateMember(@PathParam("id") Long id,
                                 @FormParam("fullName") String fullName,
                                 @FormParam("documentNumber") String documentNumber,
                                 @FormParam("email") String email,
                                 @FormParam("phone") String phone,
                                 @FormParam("student") String student) {
        boolean isStudent = student != null;
        try {
            Member m = members.update(id, fullName, documentNumber, email, phone, isStudent);
            return redirect("/members", "success", "Datos actualizados: " + m.getFullName());
        } catch (ResourceNotFoundException ex) {
            return redirect("/members", "error", ex.getMessage());
        } catch (BusinessRuleException ex) {
            MemberView typed = new MemberView(id, nz(fullName), nz(documentNumber), nz(email), nz(phone), isStudent, true, "");
            return Response.ok(memberForm(id, typed, ex.getMessage())).build();
        }
    }

    @POST
    @Path("/members/{id}/toggle")
    @Operation(summary = "Activar o desactivar un socio")
    public Response toggleMember(@PathParam("id") Long id) {
        try {
            Member m = members.toggleActive(id);
            return redirect("/members", "success", "El socio " + m.getFullName() + " ahora está "
                    + (m.isActive() ? "activo" : "inactivo"));
        } catch (ResourceNotFoundException ex) {
            return redirect("/members", "error", ex.getMessage());
        }
    }

    private TemplateInstance memberForm(Long id, MemberView member, String error) {
        return memberFormTemplate.data("active", "members").data("editing", id != null)
                .data("member", member).data("error", error);
    }



    @GET
    @Path("/plans")
    @Operation(summary = "Listado de planes y formulario para crear uno nuevo")
    public TemplateInstance plansList(@QueryParam("success") String success, @QueryParam("error") String error) {
        return plansTemplate.data("active", "plans")
                .data("rows", plans.findAll().stream().map(WebMapper::toView).toList())
                .data("success", success).data("error", error);
    }

    @POST
    @Path("/plans")
    @Consumes(MediaType.APPLICATION_FORM_URLENCODED)
    @Operation(summary = "Crear un plan")
    public Response createPlan(@FormParam("name") String name,
                               @FormParam("description") String description,
                               @FormParam("price") String price,
                               @FormParam("durationDays") String durationDays) {
        try {
            var plan = plans.create(name, description, parsePrice(price), parseInt(durationDays));
            return redirect("/plans", "success", "Plan creado: " + plan.getName());
        } catch (BusinessRuleException ex) {
            return redirect("/plans", "error", ex.getMessage());
        }
    }

    @POST
    @Path("/plans/{id}/toggle")
    @Operation(summary = "Activar o desactivar un plan")
    public Response togglePlan(@PathParam("id") Long id) {
        try {
            var plan = plans.toggleActive(id);
            return redirect("/plans", "success", "El plan " + plan.getName() + " ahora está "
                    + (plan.isActive() ? "disponible" : "no disponible"));
        } catch (ResourceNotFoundException ex) {
            return redirect("/plans", "error", ex.getMessage());
        }
    }



    private Response redirect(String path, String key, String message) {
        return Response.seeOther(URI.create(path + "?" + key + "=" + encode(message))).build();
    }

    private String encode(String text) {
        return URLEncoder.encode(text, StandardCharsets.UTF_8);
    }

    private String nz(String text) {
        return text == null ? "" : text;
    }

    static LocalDate parseDate(String text) {
        try {
            return LocalDate.parse(text);
        } catch (RuntimeException ex) {
            throw new BusinessRuleException("La fecha no es válida");
        }
    }

    private PaymentMethod parseMethod(String text) {
        try {
            return PaymentMethod.valueOf(text);
        } catch (RuntimeException ex) {
            throw new BusinessRuleException("Debe seleccionar la forma de pago");
        }
    }

    private BigDecimal parsePrice(String text) {
        try {
            return new BigDecimal(text.trim());
        } catch (RuntimeException ex) {
            throw new BusinessRuleException("El precio debe ser un número");
        }
    }

    private int parseInt(String text) {
        try {
            return Integer.parseInt(text.trim());
        } catch (RuntimeException ex) {
            throw new BusinessRuleException("La duración debe ser un número entero de días");
        }
    }
}