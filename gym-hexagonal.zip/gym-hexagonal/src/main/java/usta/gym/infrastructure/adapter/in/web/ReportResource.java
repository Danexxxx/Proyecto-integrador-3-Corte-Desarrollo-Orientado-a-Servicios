package usta.gym.infrastructure.adapter.in.web;

import io.quarkus.qute.Location;
import io.quarkus.qute.Template;
import io.quarkus.qute.TemplateInstance;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.openapi.annotations.Operation;
import org.eclipse.microprofile.openapi.annotations.tags.Tag;
import usta.gym.application.port.in.EnrollmentUseCase;
import usta.gym.domain.exception.BusinessRuleException;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.IncomeSummary;

import java.time.LocalDate;
import java.util.List;


@Path("/reports")
@ApplicationScoped
@Tag(name = "Reportes", description = "Resumen de ingresos por fechas y reportes en PDF")
public class ReportResource {

    @Inject @Location("reports.html") Template reportsTemplate;
    @Inject EnrollmentUseCase enrollments;


    @GET
    @Produces(MediaType.TEXT_HTML)
    @Operation(summary = "Pantalla de reportes: ingresos e inscripciones por rango de fechas")
    public TemplateInstance reports(@QueryParam("from") String from, @QueryParam("to") String to) {
        LocalDate today = LocalDate.now();
        String error = null;
        LocalDate start = today.withDayOfMonth(1);
        LocalDate end = today;
        try {
            if (from != null && !from.isBlank()) {
                start = WebResource.parseDate(from);
            }
            if (to != null && !to.isBlank()) {
                end = WebResource.parseDate(to);
            }
            if (end.isBefore(start)) {
                throw new BusinessRuleException("La fecha final no puede ser anterior a la inicial");
            }
        } catch (BusinessRuleException ex) {
            error = ex.getMessage();
            start = today.withDayOfMonth(1);
            end = today;
        }
        IncomeSummary summary = enrollments.summary(start, end);
        List<WebMapper.EnrollmentView> rows = enrollments.findByStartDateBetween(start, end).stream()
                .map(WebMapper::toView).toList();
        return reportsTemplate.data("active", "reports")
                .data("from", start.toString()).data("to", end.toString())
                .data("summary", WebMapper.toView(summary)).data("rows", rows).data("error", error);
    }


    @GET
    @Path("/enrollments.pdf")
    @Produces("application/pdf")
    @Operation(summary = "Descargar en PDF el reporte de inscripciones e ingresos del rango de fechas")
    public Response enrollmentsPdf(@QueryParam("from") String from, @QueryParam("to") String to) {
        LocalDate today = LocalDate.now();
        LocalDate start;
        LocalDate end;
        try {
            start = (from == null || from.isBlank()) ? today.withDayOfMonth(1) : WebResource.parseDate(from);
            end = (to == null || to.isBlank()) ? today : WebResource.parseDate(to);
        } catch (BusinessRuleException ex) {
            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.TEXT_PLAIN).entity(ex.getMessage()).build();
        }
        if (end.isBefore(start)) {
            return Response.status(Response.Status.BAD_REQUEST).type(MediaType.TEXT_PLAIN)
                    .entity("La fecha final no puede ser anterior a la inicial").build();
        }
        List<Enrollment> list = enrollments.findByStartDateBetween(start, end);
        byte[] pdf = PdfReports.enrollmentsReport(enrollments.summary(start, end), list);
        return Response.ok(pdf)
                .header("Content-Disposition", "attachment; filename=inscripciones-" + start + "_" + end + ".pdf")
                .build();
    }


    @GET
    @Path("/receipt/{id}.pdf")
    @Produces("application/pdf")
    @Operation(summary = "Descargar en PDF el comprobante de pago de una inscripción")
    public Response receiptPdf(@PathParam("id") Long id) {
        return enrollments.findById(id)
                .map(e -> Response.ok(PdfReports.receipt(e))
                        .header("Content-Disposition", "attachment; filename=comprobante-" + id + ".pdf").build())
                .orElseGet(() -> Response.status(Response.Status.NOT_FOUND).type(MediaType.TEXT_PLAIN)
                        .entity("No existe la inscripción con id " + id).build());
    }
}