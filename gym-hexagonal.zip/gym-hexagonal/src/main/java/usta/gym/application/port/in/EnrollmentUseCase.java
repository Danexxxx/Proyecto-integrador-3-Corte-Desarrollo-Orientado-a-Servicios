package usta.gym.application.port.in;

import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.IncomeSummary;
import usta.gym.domain.model.PaymentMethod;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


public interface EnrollmentUseCase {

    Enrollment enroll(Long memberId, Long planId, LocalDate startDate, PaymentMethod method);

    Enrollment cancel(Long enrollmentId);


    List<Enrollment> findAll();

    Optional<Enrollment> findById(Long id);


    List<Enrollment> findByStartDateBetween(LocalDate from, LocalDate to);

    IncomeSummary summary(LocalDate from, LocalDate to);
}