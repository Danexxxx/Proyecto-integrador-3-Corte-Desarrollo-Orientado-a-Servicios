package usta.gym.application.port.in;

import usta.gym.domain.model.Plan;

import java.math.BigDecimal;
import java.util.List;


public interface ManagePlansUseCase {

    Plan create(String name, String description, BigDecimal price, int durationDays);

    Plan toggleActive(Long id);

    List<Plan> findAll();

    List<Plan> findActive();
}