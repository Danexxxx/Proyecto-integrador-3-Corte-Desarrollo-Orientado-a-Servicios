package usta.gym.application.usecase;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import usta.gym.application.exception.ResourceNotFoundException;
import usta.gym.application.port.in.ManageMembersUseCase;
import usta.gym.application.port.out.MemberRepository;
import usta.gym.domain.exception.BusinessRuleException;
import usta.gym.domain.model.Member;
import usta.gym.domain.service.MemberRules;

import java.util.List;
import java.util.Optional;


@ApplicationScoped
public class MembersService implements ManageMembersUseCase {

    private final MemberRepository memberRepository;
    private final MemberRules rules = new MemberRules();

    @Inject
    public MembersService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    @Override
    public Member create(String fullName, String documentNumber, String email, String phone, boolean student) {
        rules.validate(fullName, documentNumber, email, phone);
        ensureDocumentIsFree(documentNumber.trim(), null);

        Member member = Member.builder()
                .fullName(fullName.trim())
                .documentNumber(documentNumber.trim())
                .email(email.trim().toLowerCase())
                .phone(phone.trim())
                .student(student)
                .build();
        return memberRepository.save(member);
    }

    @Override
    public Member update(Long id, String fullName, String documentNumber, String email, String phone, boolean student) {
        Member member = getOrThrow(id);
        rules.validate(fullName, documentNumber, email, phone);
        ensureDocumentIsFree(documentNumber.trim(), id);

        member.setFullName(fullName.trim());
        member.setDocumentNumber(documentNumber.trim());
        member.setEmail(email.trim().toLowerCase());
        member.setPhone(phone.trim());
        member.setStudent(student);
        return memberRepository.save(member);
    }

    @Override
    public Member toggleActive(Long id) {
        Member member = getOrThrow(id);
        member.setActive(!member.isActive());
        return memberRepository.save(member);
    }

    @Override
    public List<Member> findAll() {
        return memberRepository.findAll();
    }

    @Override
    public Optional<Member> findById(Long id) {
        return memberRepository.findById(id);
    }

    private Member getOrThrow(Long id) {
        return memberRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el socio con id " + id));
    }


    private void ensureDocumentIsFree(String documentNumber, Long ownId) {
        memberRepository.findByDocumentNumber(documentNumber).ifPresent(other -> {
            if (!other.getId().equals(ownId)) {
                throw new BusinessRuleException("Ya existe un socio con el documento " + documentNumber);
            }
        });
    }
}
