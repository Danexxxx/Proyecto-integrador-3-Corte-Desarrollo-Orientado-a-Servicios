package usta.gym.application.usecase;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import usta.gym.application.exception.ResourceNotFoundException;
import usta.gym.application.port.in.EnrollmentUseCase;
import usta.gym.application.port.out.EnrollmentRepository;
import usta.gym.application.port.out.MemberRepository;
import usta.gym.application.port.out.PlanRepository;
import usta.gym.domain.exception.BusinessRuleException;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.IncomeSummary;
import usta.gym.domain.model.Member;
import usta.gym.domain.model.PaymentMethod;
import usta.gym.domain.model.Plan;
import usta.gym.domain.service.MembershipService;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;


@ApplicationScoped
public class EnrollmentService implements EnrollmentUseCase {

    private final EnrollmentRepository enrollmentRepository;
    private final MemberRepository memberRepository;
    private final PlanRepository planRepository;
    private final MembershipService membershipService = new MembershipService();

    @Inject
    public EnrollmentService(EnrollmentRepository enrollmentRepository,
                             MemberRepository memberRepository,
                             PlanRepository planRepository) {
        this.enrollmentRepository = enrollmentRepository;
        this.memberRepository = memberRepository;
        this.planRepository = planRepository;
    }

    @Override
    public Enrollment enroll(Long memberId, Long planId, LocalDate startDate, PaymentMethod method) {
        if (memberId == null || planId == null) {
            throw new BusinessRuleException("Debe seleccionar un socio y un plan");
        }
        Member member = memberRepository.findById(memberId)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el socio con id " + memberId));
        Plan plan = planRepository.findById(planId)
                .orElseThrow(() -> new ResourceNotFoundException("No existe el plan con id " + planId));

        List<Enrollment> history = refresh(enrollmentRepository.findByMemberId(memberId));
        Enrollment enrollment = membershipService.enroll(member, plan, history, startDate, method, LocalDate.now());
        return enrollmentRepository.save(enrollment);
    }

    @Override
    public Enrollment cancel(Long enrollmentId) {
        Enrollment enrollment = enrollmentRepository.findById(enrollmentId)
                .orElseThrow(() -> new ResourceNotFoundException("No existe la inscripción con id " + enrollmentId));
        membershipService.cancel(enrollment, LocalDate.now());
        return enrollmentRepository.save(enrollment);
    }

    @Override
    public List<Enrollment> findAll() {
        return refresh(enrollmentRepository.findAll());
    }

    @Override
    public Optional<Enrollment> findById(Long id) {
        return enrollmentRepository.findById(id);
    }

    @Override
    public List<Enrollment> findByStartDateBetween(LocalDate from, LocalDate to) {
        return refresh(enrollmentRepository.findByStartDateBetween(from, to));
    }

    @Override
    public IncomeSummary summary(LocalDate from, LocalDate to) {
        return membershipService.summarize(from, to, findByStartDateBetween(from, to));
    }


    private List<Enrollment> refresh(List<Enrollment> enrollments) {
        LocalDate today = LocalDate.now();
        for (Enrollment enrollment : enrollments) {
            if (membershipService.refreshStatus(enrollment, today)) {
                enrollmentRepository.save(enrollment);
            }
        }
        return enrollments;
    }
}