package usta.gym.application.port.in;

import usta.gym.domain.model.Member;

import java.util.List;
import java.util.Optional;


public interface ManageMembersUseCase {

    Member create(String fullName, String documentNumber, String email, String phone, boolean student);

    Member update(Long id, String fullName, String documentNumber, String email, String phone, boolean student);


    Member toggleActive(Long id);

    List<Member> findAll();

    Optional<Member> findById(Long id);
}
