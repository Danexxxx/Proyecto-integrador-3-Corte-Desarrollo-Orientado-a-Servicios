package usta.gym.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDate;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Member {

    private Long id;
    private String fullName;
    private String documentNumber;
    private String email;
    private String phone;


    private boolean student;


    @Builder.Default
    private boolean active = true;

    @Builder.Default
    private LocalDate registeredAt = LocalDate.now();
}