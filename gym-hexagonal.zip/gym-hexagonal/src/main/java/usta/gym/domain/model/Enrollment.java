package usta.gym.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Enrollment {

    private Long id;
    private Member member;
    private Plan plan;
    private LocalDate startDate;
    private LocalDate endDate;


    private BigDecimal listPrice;
    private BigDecimal discount;
    private BigDecimal amountPaid;

    private PaymentMethod paymentMethod;

    @Builder.Default
    private EnrollmentStatus status = EnrollmentStatus.ACTIVE;


    @Builder.Default
    private BigDecimal refund = BigDecimal.ZERO;

    @Builder.Default
    private LocalDateTime createdAt = LocalDateTime.now();
}