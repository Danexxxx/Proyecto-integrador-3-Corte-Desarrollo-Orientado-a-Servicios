package usta.gym.domain.service;

import usta.gym.domain.exception.BusinessRuleException;

import java.math.BigDecimal;


public class PlanRules {

    public static final int MAX_DURATION_DAYS = 730;


    public void validate(String name, BigDecimal price, int durationDays) {
        if (name == null || name.isBlank()) {
            throw new BusinessRuleException("El nombre del plan es obligatorio");
        }
        if (price == null || price.signum() <= 0) {
            throw new BusinessRuleException("El precio del plan debe ser mayor que cero");
        }
        if (durationDays < 1 || durationDays > MAX_DURATION_DAYS) {
            throw new BusinessRuleException("La duración debe estar entre 1 y " + MAX_DURATION_DAYS + " días");
        }
    }
}