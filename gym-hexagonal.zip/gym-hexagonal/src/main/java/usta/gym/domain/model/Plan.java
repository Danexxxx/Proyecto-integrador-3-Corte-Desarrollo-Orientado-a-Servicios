package usta.gym.domain.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
@ToString
public class Plan {

    private Long id;
    private String name;
    private String description;
    private BigDecimal price;
    private int durationDays;


    @Builder.Default
    private boolean active = true;
}