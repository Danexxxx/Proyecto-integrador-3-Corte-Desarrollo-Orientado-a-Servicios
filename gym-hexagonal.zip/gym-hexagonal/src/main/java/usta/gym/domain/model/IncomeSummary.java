package usta.gym.domain.model;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public record IncomeSummary(
        LocalDate from,
        LocalDate to,
        long totalEnrollments,
        long cancelledEnrollments,
        BigDecimal gross,
        BigDecimal refunds,
        BigDecimal net,
        List<PlanIncome> byPlan) {
}