package usta.gym.domain.service;

import usta.gym.domain.exception.BusinessRuleException;
import usta.gym.domain.model.Enrollment;
import usta.gym.domain.model.EnrollmentStatus;
import usta.gym.domain.model.IncomeSummary;
import usta.gym.domain.model.Member;
import usta.gym.domain.model.PaymentMethod;
import usta.gym.domain.model.Plan;
import usta.gym.domain.model.PlanIncome;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;


public class MembershipService {

    public static final int MAX_DAYS_AHEAD = 30;
    public static final int FULL_REFUND_DAYS = 3;

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final PricingService pricing = new PricingService();


    public Enrollment enroll(Member member, Plan plan, List<Enrollment> history,
                             LocalDate startDate, PaymentMethod method, LocalDate today) {
        if (member == null) {
            throw new BusinessRuleException("El socio no existe");
        }
        if (plan == null) {
            throw new BusinessRuleException("El plan no existe");
        }
        if (!member.isActive()) {
            throw new BusinessRuleException("El socio está inactivo y no puede inscribirse");
        }
        if (!plan.isActive()) {
            throw new BusinessRuleException("El plan \"" + plan.getName() + "\" ya no está disponible");
        }
        if (method == null) {
            throw new BusinessRuleException("Debe seleccionar la forma de pago");
        }
        if (startDate == null) {
            throw new BusinessRuleException("La fecha de inicio es obligatoria");
        }
        if (startDate.isBefore(today)) {
            throw new BusinessRuleException("La fecha de inicio no puede ser anterior a hoy");
        }
        if (startDate.isAfter(today.plusDays(MAX_DAYS_AHEAD))) {
            throw new BusinessRuleException("La fecha de inicio no puede superar " + MAX_DAYS_AHEAD + " días desde hoy");
        }

        LocalDate endDate = startDate.plusDays(plan.getDurationDays() - 1L);


        for (Enrollment other : history) {
            boolean overlaps = other.getStatus() != EnrollmentStatus.CANCELLED
                    && !startDate.isAfter(other.getEndDate())
                    && !other.getStartDate().isAfter(endDate);
            if (overlaps) {
                throw new BusinessRuleException("El socio ya tiene una inscripción (" + other.getPlan().getName()
                        + ") vigente hasta el " + DATE_FORMAT.format(other.getEndDate()));
            }
        }

        long previous = history.stream().filter(e -> e.getStatus() != EnrollmentStatus.CANCELLED).count();
        BigDecimal rate = pricing.discountRate(member, previous);
        BigDecimal discount = pricing.discountAmount(plan.getPrice(), rate);

        return Enrollment.builder()
                .member(member)
                .plan(plan)
                .startDate(startDate)
                .endDate(endDate)
                .listPrice(plan.getPrice())
                .discount(discount)
                .amountPaid(plan.getPrice().subtract(discount))
                .paymentMethod(method)
                .build();
    }


    public Enrollment cancel(Enrollment enrollment, LocalDate today) {
        if (enrollment == null) {
            throw new BusinessRuleException("La inscripción no existe");
        }
        if (enrollment.getStatus() == EnrollmentStatus.CANCELLED) {
            throw new BusinessRuleException("La inscripción ya estaba cancelada");
        }
        if (today.isAfter(enrollment.getEndDate())) {
            throw new BusinessRuleException("La inscripción ya venció y no se puede cancelar");
        }
        enrollment.setRefund(calculateRefund(enrollment, today));
        enrollment.setStatus(EnrollmentStatus.CANCELLED);
        return enrollment;
    }


    public EnrollmentStatus effectiveStatus(Enrollment enrollment, LocalDate today) {
        if (enrollment.getStatus() == EnrollmentStatus.CANCELLED) {
            return EnrollmentStatus.CANCELLED;
        }
        return today.isAfter(enrollment.getEndDate()) ? EnrollmentStatus.EXPIRED : EnrollmentStatus.ACTIVE;
    }


    public boolean refreshStatus(Enrollment enrollment, LocalDate today) {
        EnrollmentStatus current = effectiveStatus(enrollment, today);
        if (current != enrollment.getStatus()) {
            enrollment.setStatus(current);
            return true;
        }
        return false;
    }

    public IncomeSummary summarize(LocalDate from, LocalDate to, List<Enrollment> enrollments) {
        BigDecimal gross = BigDecimal.ZERO;
        BigDecimal refunds = BigDecimal.ZERO;
        long cancelled = 0;
        Map<String, long[]> counts = new LinkedHashMap<>();
        Map<String, BigDecimal> incomes = new LinkedHashMap<>();

        for (Enrollment e : enrollments) {
            BigDecimal net = e.getAmountPaid().subtract(e.getRefund());
            gross = gross.add(e.getAmountPaid());
            refunds = refunds.add(e.getRefund());
            if (e.getStatus() == EnrollmentStatus.CANCELLED) {
                cancelled++;
            }
            String plan = e.getPlan().getName();
            counts.computeIfAbsent(plan, k -> new long[1])[0]++;
            incomes.merge(plan, net, BigDecimal::add);
        }

        List<PlanIncome> byPlan = incomes.entrySet().stream()
                .map(en -> new PlanIncome(en.getKey(), counts.get(en.getKey())[0], en.getValue()))
                .sorted(Comparator.comparing(PlanIncome::income).reversed())
                .toList();

        return new IncomeSummary(from, to, enrollments.size(), cancelled, gross, refunds, gross.subtract(refunds), byPlan);
    }

    private BigDecimal calculateRefund(Enrollment enrollment, LocalDate today) {
        long elapsed = Math.max(0, ChronoUnit.DAYS.between(enrollment.getStartDate(), today));
        if (elapsed <= FULL_REFUND_DAYS) {
            return enrollment.getAmountPaid();
        }
        long total = ChronoUnit.DAYS.between(enrollment.getStartDate(), enrollment.getEndDate()) + 1;
        long remaining = Math.max(0, total - elapsed);
        return enrollment.getAmountPaid()
                .multiply(BigDecimal.valueOf(remaining))
                .divide(BigDecimal.valueOf(total), 0, RoundingMode.HALF_UP);
    }
}