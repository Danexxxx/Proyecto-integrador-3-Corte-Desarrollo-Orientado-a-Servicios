package usta.gym.domain.service;

import usta.gym.domain.model.Member;

import java.math.BigDecimal;
import java.math.RoundingMode;


public class PricingService {

    public static final BigDecimal STUDENT_RATE = new BigDecimal("0.15");
    public static final BigDecimal LOYALTY_RATE = new BigDecimal("0.10");
    public static final int LOYALTY_MIN_ENROLLMENTS = 3;


    public BigDecimal discountRate(Member member, long previousEnrollments) {
        BigDecimal rate = BigDecimal.ZERO;
        if (member.isStudent()) {
            rate = STUDENT_RATE;
        }
        if (previousEnrollments >= LOYALTY_MIN_ENROLLMENTS && LOYALTY_RATE.compareTo(rate) > 0) {
            rate = LOYALTY_RATE;
        }
        return rate;
    }


    public BigDecimal discountAmount(BigDecimal price, BigDecimal rate) {
        return price.multiply(rate).setScale(0, RoundingMode.HALF_UP);
    }
}