package usta.gym.domain.model;

import java.math.BigDecimal;


public record PlanIncome(String planName, long enrollments, BigDecimal income) {
}