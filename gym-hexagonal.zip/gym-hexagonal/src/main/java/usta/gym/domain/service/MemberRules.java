package usta.gym.domain.service;

import usta.gym.domain.exception.BusinessRuleException;


public class MemberRules {

    private static final String DOCUMENT_PATTERN = "\\d{5,12}";
    private static final String PHONE_PATTERN = "\\d{7,10}";
    private static final String EMAIL_PATTERN = "[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+";


    public void validate(String fullName, String documentNumber, String email, String phone) {
        if (fullName == null || fullName.trim().length() < 3) {
            throw new BusinessRuleException("El nombre del socio es obligatorio (mínimo 3 letras)");
        }
        if (documentNumber == null || !documentNumber.trim().matches(DOCUMENT_PATTERN)) {
            throw new BusinessRuleException("El documento debe tener solo números (entre 5 y 12 dígitos)");
        }
        if (email == null || !email.trim().matches(EMAIL_PATTERN)) {
            throw new BusinessRuleException("El correo electrónico no es válido");
        }
        if (phone == null || !phone.trim().matches(PHONE_PATTERN)) {
            throw new BusinessRuleException("El teléfono debe tener solo números (entre 7 y 10 dígitos)");
        }
    }
}