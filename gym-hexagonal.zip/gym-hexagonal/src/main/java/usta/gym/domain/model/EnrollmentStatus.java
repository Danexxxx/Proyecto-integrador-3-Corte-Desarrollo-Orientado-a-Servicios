package usta.gym.domain.model;

public enum EnrollmentStatus {
    ACTIVE("Vigente"),
    EXPIRED("Vencida"),
    CANCELLED("Cancelada");

    private final String label;

    EnrollmentStatus(String label) {
        this.label = label;
    }

    public String getLabel() {
        return label;
    }
}