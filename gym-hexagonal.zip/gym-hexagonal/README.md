# gym-hexagonal - Gimnasio PowerFit

Proyecto integrador de **Desarrollo Orientado a Servicios 2026-2** (Universidad Santo Tomás, Tunja).
Construido con **arquitectura hexagonal**, **Java + Quarkus**, **JPA/MySQL**, vistas **Qute + Bootstrap 5**,
reporte **PDF (OpenPDF)** y documentación **Swagger**. Parte de la estructura del proyecto `cine-hexagonal` del curso.

**Integrantes:** (escribir nombres del equipo)

## La propuesta en tres frases

1. **Problema:** un gimnasio lleva en papel o en Excel los planes, las inscripciones y los pagos, por lo que no sabe quién tiene la membresía vigente, cuándo vence ni cuánto ingresó en el mes.
2. **A quién le sirve:** al administrador y a la recepción del gimnasio, que registran socios, venden planes y consultan ingresos.
3. **Datos:** guarda **socios**, **planes** e **inscripciones** (con fechas, descuento, valor pagado, forma de pago, estado y reembolso) y los consulta por estado y por rango de fechas.

## Requisitos y cómo ejecutar

- **JDK 17 o superior** y el wrapper de Maven incluido (`mvnw` / `mvnw.cmd`).
- **MySQL de XAMPP encendido** (usuario `root` sin clave). La base `gimnasio` se crea sola (`createDatabaseIfNotExist=true`)
  y las tablas con `quarkus.hibernate-orm.schema-management.strategy=update`.
- Plugin **Lombok** en IntelliJ con *Enable annotation processing* activado.

```powershell
.\mvnw.cmd quarkus:dev
```

| Qué | URL |
|---|---|
| Aplicación | http://localhost:8080/ |
| Swagger UI | http://localhost:8080/q/swagger-ui |
| Documento OpenAPI | http://localhost:8080/q/openapi |
| PDF de inscripciones | http://localhost:8080/reports/enrollments.pdf |

Al primer arranque (tablas vacías) se cargan **datos de prueba**: 5 planes (uno no disponible), 8 socios (uno inactivo)
y 13 inscripciones con fechas relativas a hoy (vigentes, vencidas y canceladas). Para desactivarlo: `gym.seed.enabled=false`.
Para recargarlos, vaciar las tablas (`DELETE FROM enrollments; DELETE FROM members; DELETE FROM plans;`) y reiniciar.

## Pantallas (todo se usa desde el navegador)

| Ruta | Pantalla |
|---|---|
| `/` | **Listado** de inscripciones, indicadores y filtro por estado; cancelar y descargar comprobante |
| `/enroll` | **Formulario** para inscribir un socio a un plan (con pago) |
| `/members`, `/members/new`, `/members/{id}/edit` | Listado, registro y edición de socios; activar/desactivar |
| `/plans` | Listado y creación de planes; activar/desactivar |
| `/reports` | **Reportes**: ingresos por rango de fechas, por plan y detalle |

Los errores de las reglas de negocio y los mensajes de éxito se muestran como alertas de Bootstrap.

## Reglas de negocio (dominio)

- **Descuento:** 15% si el socio es estudiante, 10% si tiene 3 o más inscripciones previas (se aplica el mayor, no se suman).
- **Sin cruces:** un socio no puede tener dos inscripciones cuyas fechas se crucen.
- **Fecha de inicio:** no puede ser anterior a hoy ni superar 30 días hacia adelante.
- **Disponibilidad:** un socio inactivo o un plan no disponible no se pueden inscribir.
- **Documento único** por socio; validación de nombre, documento, correo y teléfono.
- **Cancelación:** reembolso del **100%** durante los primeros 3 días; después, **proporcional** a los días que faltan. No se cancela algo ya vencido o ya cancelado.
- **Vencimiento:** las inscripciones cuya fecha final pasó se marcan automáticamente como *Vencidas*.

## Arquitectura: ¿qué busco? → ¿dónde está?

```
src/main/java/usta/gym/
|-- domain/                       NÚCLEO (sin @Entity, sin Quarkus, sin HTML)
|   |-- model/                    Member, Plan, Enrollment, enums, IncomeSummary, PlanIncome
|   |-- service/                  MembershipService, PricingService, MemberRules, PlanRules
|   |-- exception/                BusinessRuleException
|-- application/
|   |-- port/in/                  PUERTOS DE ENTRADA (casos de uso): ManageMembers, ManagePlans, Enrollment
|   |-- port/out/                 PUERTOS DE SALIDA: MemberRepository, PlanRepository, EnrollmentRepository
|   |-- usecase/                  MembersService, PlansService, EnrollmentService
|   |-- exception/                ResourceNotFoundException
|-- infrastructure/
    |-- adapter/in/web/           ADAPTADOR WEB (única entrada): WebResource, ReportResource, WebMapper, PdfReports, Formats
    |-- adapter/out/persistence/  ADAPTADOR JPA: entity/, repository/ (Panache), adapter/, mapper/
    |-- config/DataSeeder         Datos de prueba
src/main/resources/templates/     Vistas Qute (base, index, enroll, members, member-form, plans, reports)
```

| Quiero ver... | Archivo |
|---|---|
| Las entidades del negocio | `domain/model/` |
| Reglas de precio y descuento | `domain/service/PricingService.java` |
| Reglas de inscripción, cancelación y reembolso | `domain/service/MembershipService.java` |
| Los puertos de entrada / salida | `application/port/in/` y `application/port/out/` |
| La orquestación de cada caso de uso | `application/usecase/` |
| Las tablas MySQL (`@Entity`, `@ManyToOne`, `@JoinColumn`) | `.../persistence/entity/` (`EnrollmentEntity` tiene `member_id` y `plan_id`) |
| Dominio ⇄ entidad | `.../persistence/mapper/` |
| Quién implementa los puertos de salida | `.../persistence/adapter/Jpa*Repository.java` |
| Las rutas web y Swagger (`@Tag`, `@Operation`) | `adapter/in/web/WebResource.java` y `ReportResource.java` |
| El PDF | `adapter/in/web/PdfReports.java` |
| La configuración de la base de datos y Swagger | `src/main/resources/application.properties` |

**Regla de dependencias:** el dominio no importa nada de `application` ni de `infrastructure`; los casos de uso solo
conocen puertos; los adaptadores dependen hacia adentro. No hay adaptador REST ni de consola.

## Base de datos

Tablas `members`, `plans` y `enrollments`. `enrollments` referencia a las otras dos con llaves foráneas
(`member_id`, `plan_id`). Evidencia: phpMyAdmin → base `gimnasio` → *Diseñador* (relaciones) y *Examinar* (datos).

## Reportes PDF

- `/reports/enrollments.pdf?from=YYYY-MM-DD&to=YYYY-MM-DD`: título, resumen de ingresos, ingresos por plan y tabla de detalle.
- `/reports/receipt/{id}.pdf`: comprobante de pago de una inscripción.

Ambos se descargan desde los botones de la vista.

## Convenciones

Identificadores en inglés; mensajes y comentarios en español. Modelos de dominio anémicos con Lombok; las reglas viven en los servicios de dominio.